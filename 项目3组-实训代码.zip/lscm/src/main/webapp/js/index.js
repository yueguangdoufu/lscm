$("#schManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("SchoolManagement.html");
});
$("#classManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("classManagement.html");
});
$("#stuManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("studentManagement.html");
});
$("#positionManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("positionManagement.html");
});
$("#depManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("department.html");
});
$("#employeeManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("employeeManagement.html");
});
$("#areaCounts").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("areaCounts.html");
});
$("#schoolCounts").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("schoolCounts.html");
});
$("#schoolActManagement").on("click", function () {
    // $.ajaxSetup({cache: false});
    $(".main-container").load("schoolActManagement.html");
});